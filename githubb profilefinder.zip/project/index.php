<?php
session_start();
require "config.php";

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $username = trim($_POST["username"]);
  $password = $_POST["password"];

  if ($username === "" || $password === "") {
    $error = "Please fill in both fields.";
  } elseif (strlen($password) < 6) {
    $error = "Password must be at least 6 characters.";
  } else {
    $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {
      $error = "That username is already taken.";
    } else {
      $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

      $insert = mysqli_prepare($conn, "INSERT INTO users (username, password) VALUES (?, ?)");
      mysqli_stmt_bind_param($insert, "ss", $username, $hashedPassword);

      if (mysqli_stmt_execute($insert)) {
        $success = "Account created! You can now log in.";
      } else {
        $error = "Something went wrong. Please try again.";
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon.png">
  <title>Sign Up - PROFILE FINDER</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="auth.css">
</head>
<body id="body">

  <main class="auth-main">
    <div class="heading-title | scaleUp">
      <h1>GITHUB PROFILE FINDER</h1>
    </div>

    <div class="auth-box | scaleUp">
      <h2>Create an account</h2>
      <p class="auth-subtitle">Sign up to start searching GitHub users.</p>

      <?php if ($error): ?>
        <p class="form-message error"><?php echo htmlspecialchars($error); ?></p>
      <?php endif; ?>

      <?php if ($success): ?>
        <p class="form-message success"><?php echo htmlspecialchars($success); ?></p>
      <?php endif; ?>

      <form method="POST" action="index.php">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" placeholder="Choose a username" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="At least 6 characters" required minlength="6">
        <confirm
        <label for="password"> Confirm Password</label>
        <input type="password" id="confirm_password" name="confirm_password" placeholder="At least 6 characters" required minlength="6">

        <button type="submit" class="btn auth-btn">Sign Up</button>
      </form>

      <p class="auth-switch">Already have an account? <a href="login.php">Log in</a></p>
    </div>
  </main>

</body>
</html>
