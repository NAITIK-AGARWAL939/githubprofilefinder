-- Run this file first to set up the database.
-- In phpMyAdmin: Import this file.
-- In terminal: mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS devfinder;
USE devfinder;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
