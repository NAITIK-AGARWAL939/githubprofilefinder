# DevFinder — GitHub User Search (PHP + MySQL, original design)

Same PHP + MySQL login/register/search functionality as before, but using
your original site's exact design — same CSS, fonts, dark mode toggle,
animations, and icons.

## Files

```
php-project-v2/
├── schema.sql        Run this first to create the database and users table
├── config.php         Database connection settings
├── register.php        Sign up page
├── login.php           Login page
├── logout.php          Destroys the session
├── search.php           Protected page — search any GitHub username
├── style.css           Your original CSS, unchanged
├── auth.css            Extra styles for the login/register cards (uses the same CSS variables as style.css)
├── theme.js             Dark/light toggle (same behavior as your original app)
└── assets/              Your original icons, avatar, error image, favicon
```

## Setup

1. Import `schema.sql` into MySQL (phpMyAdmin → Import, or
   `mysql -u root -p < schema.sql`)
2. Check `config.php` matches your MySQL credentials (defaults work for
   XAMPP/WAMP: `root` / no password)
3. Put the folder in your web root, e.g. `htdocs/php-project-v2/`
4. Start Apache + MySQL
5. Visit `register.php`, create an account, log in, then search

If you're using PHP's built-in server instead of Apache:
```
php -S localhost:8000
```

## What's different from your original site

- Search is now server-side (PHP + cURL calling the GitHub API) instead of
  client-side JavaScript `fetch`.
- You now need to log in before you can search — `search.php` checks the
  PHP session and redirects to `login.php` if you're not logged in.
- The dark/light toggle still works exactly the same way, just pulled into
  its own `theme.js` file.
- Everything else — layout, animations, colors, fonts — is unchanged.
