

let DarkMode = localStorage.getItem("Darkmode");
const ThemeToggle = document.querySelector(".theme-select");
const Dark = document.querySelector(".theme");
const light = document.querySelector(".light");
const SunIcon = document.querySelector(".sun");
const MoonIcon = document.querySelector(".moon");

const EnableSunIcon = () => {
  Dark.classList.add("none");
  light.classList.remove("none");
  MoonIcon.classList.add("none");
  SunIcon.classList.remove("none");
};

const DisableSunIcon = () => {
  light.classList.add("none");
  Dark.classList.remove("none");
  MoonIcon.classList.remove("none");
  SunIcon.classList.add("none");
};

const EnableDarkMode = () => {
  document.body.classList.add("DarkMode");
  EnableSunIcon();
  localStorage.setItem("Darkmode", "enabled");
};

const DisableDarkMode = () => {
  document.body.classList.remove("DarkMode");
  DisableSunIcon();
  localStorage.setItem("Darkmode", "disabled");
};

if (DarkMode === "enabled") {
  EnableDarkMode();
}

ThemeToggle.addEventListener("click", () => {
  DarkMode = localStorage.getItem("Darkmode");
  if (DarkMode !== "enabled") {
    EnableDarkMode();
  } else {
    DisableDarkMode();
  }
});
