<?php
session_start();
require "config.php";

if (isset($_SESSION["username"])) {
  header("Location: search.php");
  exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $username = trim($_POST["username"]);
  $password = $_POST["password"];

  if ($username === "" || $password === "") {
    $error = "Please fill in both fields.";
  } else {
    $stmt = mysqli_prepare($conn, "SELECT id, username, password FROM users WHERE username = ?");
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user["password"])) {
      $_SESSION["user_id"] = $user["id"];
      $_SESSION["username"] = $user["username"];
      header("Location: search.php");
      exit();
    } else {
      $error = "Invalid username or password.";
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon.png">
  <title>Login - GITHUB PROFILE FINDER</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="auth.css">
</head>
<body id="body">

  <main class="auth-main">
    <div class="heading-title | scaleUp">
      <h1>GITHUB PROFILE FINDER</h1>
    </div>

    <div class="auth-box | scaleUp">
      <h2>Log in to your account</h2>
      <p class="auth-subtitle">Search GitHub users once you're logged in.</p>

      <?php if ($error): ?>
        <p class="form-message error"><?php echo htmlspecialchars($error); ?></p>
      <?php endif; ?>

      <form method="POST" action="login.php">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" placeholder="Enter your username" required>

        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" required>
        
        

        <button type="submit" class="btn auth-btn">Log In</button>
      </form>

      <p class="auth-switch">Don't have an account? <a href="register.php">Sign up</a></p>
    </div>
  </main>

</body>
</html>
